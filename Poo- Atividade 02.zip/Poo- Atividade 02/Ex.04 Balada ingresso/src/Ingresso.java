
public abstract class  Ingresso{
public float valor = 20;


public  float imprimeValor() {
	return valor;
}



}
