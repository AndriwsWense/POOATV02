
public class CamaroteInferior extends Vip {
private int localIngresso;

private int getLocalIngresso() {
	return localIngresso;
}

private void setLocalIngresso(int localIngresso) {
	this.localIngresso = localIngresso;
}
public void imprimir() {
	System.out.println(getLocalIngresso());
	}
}
