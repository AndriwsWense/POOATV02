
public class normal extends Ingresso {
public void ingressoNormal() {
	System.out.println("Ingresso normal");
}
	@Override
	public float imprimeValor() {
		// TODO Auto-generated method stub
		return 0;
	}

}
