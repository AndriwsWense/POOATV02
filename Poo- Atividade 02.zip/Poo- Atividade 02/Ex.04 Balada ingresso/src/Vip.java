
public class Vip extends Ingresso {
	float valor_ad = 10;
	
	public float valorVip() {
		return valor+valor_ad;
	}

	@Override
	public float imprimeValor() {
		// TODO Auto-generated method stub
		return 0;
	}
}
